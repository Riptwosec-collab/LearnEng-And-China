# Security Policy

## Supported versions

This project tracks a single `main` branch. Only the latest commit on `main`
receives security fixes.

## Reporting a vulnerability

If you discover a security vulnerability (e.g. an auth bypass, data leak,
SSRF, or a way to abuse the AI/speech endpoints to run up API costs on
someone else's account), please **do not** open a public GitHub issue.

Instead:

1. Email the maintainer directly (see the GitHub profile/commit history for
   a contact address), with:
   - A description of the issue and its impact
   - Steps to reproduce
   - Any relevant logs/screenshots
2. Allow a reasonable amount of time for a fix before any public disclosure.

## Scope notes specific to this project

- **AI/speech endpoints** (`/api/ai-tutor/chat`, `/api/writing/correct`,
  `/api/quiz/generate`, `/api/speech/stt`, `/api/speech/tts`) call paid
  third-party AI providers. They are protected by a basic per-IP rate limiter
  (`lib/rate-limit.ts`), but that limiter is in-memory and per-instance — if
  you deploy to multiple serverless instances, replace it with a shared store
  (e.g. Upstash Redis) before relying on it for cost protection in production.
- **Environment variables**: never commit `.env` or real API keys. Use
  `.env.example` as the template and `npm run env:check` to validate your
  local setup.
- **Database**: production schema changes should go through Prisma
  migrations (`npm run prisma:migrate:deploy`), not `prisma db push`, so
  changes are auditable and reversible.
