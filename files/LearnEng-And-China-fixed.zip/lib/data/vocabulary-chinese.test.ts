import { describe, expect, it } from "vitest";
import { chineseVocabularyReal } from "@/lib/data/vocabulary-chinese";

describe("chineseVocabularyReal", () => {
  it("has 615 entries (41 categories x 15 words)", () => {
    expect(chineseVocabularyReal).toHaveLength(615);
  });

  it("has exactly 15 entries per category", () => {
    const counts = new Map<string, number>();
    for (const item of chineseVocabularyReal) {
      counts.set(item.category, (counts.get(item.category) ?? 0) + 1);
    }
    expect(counts.size).toBe(41);
    for (const [, count] of counts) {
      expect(count).toBe(15);
    }
  });

  it("has unique ids", () => {
    const ids = new Set(chineseVocabularyReal.map((item) => item.id));
    expect(ids.size).toBe(chineseVocabularyReal.length);
  });

  it("never contains the old fake placeholder pattern (hanzi with a trailing round number)", () => {
    const fakePattern = /[0-9]$/; // e.g. "学习2", "买47"
    const offenders = chineseVocabularyReal.filter((item) => fakePattern.test(item.word));
    expect(offenders).toEqual([]);
  });

  it("never repeats the hanzi as its own 'Thai pronunciation' (the old bug)", () => {
    const offenders = chineseVocabularyReal.filter((item) => item.thaiPronunciation === item.word);
    expect(offenders).toEqual([]);
  });

  it("gives every entry a non-empty hanzi, pinyin, meaning, and example sentence", () => {
    for (const item of chineseVocabularyReal) {
      expect(item.word.length).toBeGreaterThan(0);
      expect(item.chineseHanzi?.length ?? 0).toBeGreaterThan(0);
      expect(item.pinyin?.length ?? 0).toBeGreaterThan(0);
      expect(item.thaiMeaning.length).toBeGreaterThan(0);
      expect(item.exampleSentence.length).toBeGreaterThan(0);
    }
  });

  it("gives every entry a valid HSK level between 1 and 6", () => {
    for (const item of chineseVocabularyReal) {
      expect(item.hskLevel).toBeGreaterThanOrEqual(1);
      expect(item.hskLevel).toBeLessThanOrEqual(6);
    }
  });

  it("gives every multiple-choice quiz exactly 4 distinct choices that include the correct answer", () => {
    for (const item of chineseVocabularyReal) {
      expect(item.miniQuizChoices).toHaveLength(4);
      expect(new Set(item.miniQuizChoices)).toContain(item.miniQuizAnswer);
      expect(new Set(item.miniQuizChoices).size).toBe(4);
    }
  });
});
