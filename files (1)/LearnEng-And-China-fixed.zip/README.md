# LinguaQuest AI

[![QA](https://github.com/Riptwosec-collab/LearnEng-And-China/actions/workflows/qa.yml/badge.svg)](https://github.com/Riptwosec-collab/LearnEng-And-China/actions/workflows/qa.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D20-339933)](./package.json)

เว็บแอพเรียนภาษาอังกฤษและภาษาจีนกลางสำหรับผู้ใช้ไทย ตั้งแต่ A1-C1 พร้อม Vocabulary, Speaking, Listening, Reading, Writing, Grammar, AI Tutor, Review, Dashboard, Admin CMS, Supabase, AI provider adapter, STT/TTS, QA workflow, Vercel config และ content expansion

## Phase Status

- Phase 1: Project Setup - Done
- Phase 2: Database & Mock Data - Done
- Phase 3: Dashboard & Learning Path - Done
- Phase 4: Vocabulary System (data model, SRS, UI) - Done. Content itself: see "Vocabulary Content Status" below
- Phase 5: Speaking & Listening - Done
- Phase 6: Reading & Writing - Done
- Phase 7: Grammar & AI Tutor - Done
- Phase 8: Admin CMS & Import - Done
- Phase 9: Polish UX/UI - Done
- Phase 10: Production Ready - Done
- Phase 11: User Progress / Placement / Profile - Done
- Phase 12: Launch / PWA / Beta Readiness - Done
- Phase 13: Real Supabase Auth & Database - Done
- Phase 14: Real AI Integration - Done
- Phase 15: Real STT/TTS Speaking System - Done
- Phase 16: Build Fix & QA - Done
- Phase 17: Vercel deploy config - Done
- Phase 18: Content Expansion tooling (`scripts/expand-vocabulary.ts`) - exists, but see the note below before running it

## Vocabulary Content Status

- **English: 1,107+ real, hand-curated words/phrases** across all 41 daily-life categories — `lib/data/vocabulary-english.ts`. The original 41x15 base set is being expanded category-by-category with additional genuine vocabulary (currently done: home, bedroom, bathroom, kitchen, cooking, shopping, convenience-store; the rest still have the original 15 each). Each entry has genuine IPA, a real Thai phonetic approximation, an accurate Thai meaning, and a natural example sentence.
- **Chinese: 615 real, hand-curated words/phrases** across the same 41 categories — `lib/data/vocabulary-chinese.ts`. Each entry has correct pinyin (with tone marks), an accurate HSK level (1-6), a real Thai phonetic approximation, an accurate Thai meaning, and a natural example sentence.
- Both languages used to be generators that recycled a ~40-word base list with index suffixes appended (e.g. `"address 2"`, `"学习2"`) — that has been fully replaced with genuine content for both languages.
- ⚠️ **Do not run `npm run content:expand` / `npm run content:10k`** expecting real content. That generator (`lib/data/phase18-vocabulary-expansion.ts`) produces template strings like `"book home 1"` or `"买47"` by mashing a verb + category name + a number together — useful for stress-testing UI with large datasets, but not real vocabulary. If you need more words per category, add them the same way `vocabulary-english.ts` / `vocabulary-chinese.ts` were built: genuine words with accurate meanings and example sentences, organized by category.

## Run

```bash
npm install
cp .env.example .env
npm run dev
```

Open:

```bash
http://localhost:3000
```

## Production Setup

After filling real environment values, run:

```bash
npm run env:check
npm run prisma:generate
npm run prisma:migrate:deploy
npm run seed
npm run content:expand
npm run qa
```

Or run the combined setup command:

```bash
npm run setup:production
```

## Database Setup

For local prototyping (no migration history, fastest iteration):

```bash
npm run prisma:generate
npm run prisma:push
npm run seed
```

For real schema changes that should be tracked and deployable, create a
migration instead:

```bash
npm run prisma:migrate:dev -- --name <short_description>
```

In production/CI, apply already-committed migrations with:

```bash
npm run prisma:migrate:deploy
```

`prisma db push` does not create migration files — it's fine for quick local
experiments, but production schema changes should go through
`prisma migrate dev` / `prisma migrate deploy` so they're versioned and
reversible.

See:

```txt
docs/SUPABASE_PRODUCTION_SETUP.md
```

## Real Integrations

### Supabase + PostgreSQL

- `lib/supabase/server.ts`
- `lib/supabase/client.ts`
- `lib/supabase/middleware.ts`
- `lib/db/prisma.ts`
- `lib/auth/session.ts`

### AI Provider Adapter

- `lib/ai/openai.ts`
- Supports `openai`, `openrouter`, and `gemini` through `AI_PROVIDER`
- `POST /api/ai-tutor/chat`
- `POST /api/writing/correct`
- `POST /api/quiz/generate`

All AI and speech endpoints are protected by a basic per-IP rate limiter
(`lib/rate-limit.ts`) to avoid runaway API costs from abuse. It's in-memory
and per-instance — for multi-instance production deployments, swap it for a
shared store (e.g. `@upstash/ratelimit`).

See:

```txt
docs/AI_PROVIDER_SETUP.md
```

### Speech

- `lib/speech/browser-speech.ts`
- `POST /api/speech/stt`
- `POST /api/speech/tts`

## QA

```bash
npm run typecheck
npm run lint
npm run test
npm run build
npm run qa
npm run smoke
```

Unit tests live next to the code they cover (`lib/**/*.test.ts`), run with
[Vitest](https://vitest.dev). See `lib/data/srs.test.ts` for an example
covering the spaced-repetition scheduler.

GitHub Actions workflow:

```txt
.github/workflows/qa.yml
```

## Content Expansion

```bash
npm run content:export
npm run content:expand
npm run content:10k
```

Preview API:

```txt
GET /api/content/expanded-vocabulary
```

## Deployment

See:

```txt
docs/DEPLOYMENT_RUNBOOK.md
```

## Important Pages

- `/`
- `/auth/login`
- `/auth/register`
- `/onboarding`
- `/placement-test`
- `/dashboard`
- `/learn`
- `/paths`
- `/paths/[id]`
- `/lessons/[id]`
- `/vocabulary`
- `/vocabulary/[id]`
- `/review`
- `/flashcards`
- `/speaking`
- `/speaking/roleplay`
- `/listening`
- `/reading`
- `/writing`
- `/grammar`
- `/ai-tutor`
- `/progress`
- `/profile`
- `/settings`
- `/admin`
- `/admin/vocabulary`
- `/admin/lessons`
- `/admin/import`
- `/admin/system`

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for setup, the local QA checklist,
and the database migration workflow.

## Security

See [SECURITY.md](./SECURITY.md) for how to report a vulnerability.

## License

[MIT](./LICENSE)
